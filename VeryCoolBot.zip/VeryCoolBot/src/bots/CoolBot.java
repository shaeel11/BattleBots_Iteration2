package bots;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;

import arena.BattleBotArena;
import arena.BotInfo;
import arena.Bullet;

public class CoolBot extends Bot {
	
	Image up, down, left, right, current;
	private int move;
	BotHelper helper = new BotHelper(); 
	BotInfo me;
	
	
	//you can also use this to find the y displacement
		public double calcDisplacement(double botX, double bulletX){
			return bulletX - botX;
		}
	
	public CoolBot() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void newRound() {
		// TODO Auto-generated method stub

	}
	
	
	/*If(b.getX()>me.getX())    CoolBot.setX(me.getX()-=2); 
	If(b.getX()>me.getX())    CoolBot.setX(me.getX()+=2); 
	If(b.getY()>me.getY())    me.setY(me.getY()-=2); 
	If(b.getY()>me.getY())    
	me.setY(me.getY()+=2);
	*/ 

	double dodge(double botX, double bulletX, double botY, double bulletY, double calcDisplacement, double calcDistance){
		
		
		try { 
			

			
			if(calcDistance<10) {
				
				return BattleBotArena.RIGHT;
				
			}				
			
		if(bulletX>botX) {
			
			return BattleBotArena.LEFT;
			
		}
		
		if(bulletX<botX) {
			
			return BattleBotArena.RIGHT;
			
		}
		
		if(bulletY>botY) {
			
			
			
		}
		
		if(bulletY<botY) {
			
			return BattleBotArena.DOWN;
			
		}
		
	}//try
		
		catch(Exception e){
			e.printStackTrace();
		}//catch
		
		return BattleBotArena.UP;
		
	}//dodge
		
	
	@Override
	public int getMove(BotInfo me, boolean shotOK, BotInfo[] liveBots, BotInfo[] deadBots, Bullet[] bullet) {
		try {
			
			
			//GET DEAD BOTS
			if(deadBots.length>0) {
			
			BotInfo closestDead = helper.findClosest(me, deadBots);
	
			
			//LEFT
			if(closestDead.getX() < me.getX()) {
				
				current = left;
				return BattleBotArena.LEFT;
				
			}
			
			//RIGHT
			else if(closestDead.getX() > me.getX()) {
				
				current = right;
				return BattleBotArena.RIGHT;
					
			}
			
			//UP
			if(closestDead.getY() < me.getY()) {
				
				current = up;
				return BattleBotArena.UP;
				
			}
			
			//DOWN
			else if(closestDead.getY() > me.getY()) {
				
				current = down;
				return BattleBotArena.DOWN;
				
			}
			
			}//if deadBots > 0
			
									
			/*If(me.getX()>closestBot.getX())    closestBot.setX(closestBot.getX()-=2); 
			If(me.getX()>enemy.getX())    Enemy.setX(enemy.getX()+=2); 
			If(me.getY()>enemy.getY())    Enemy.setY(enemy.getY()-=2); 
			If(me.getY()>enemy.getY())    Enemy.setY(enemy.getY()+=2);
			
			/*If(b.getX()>me.getX())    CoolBot.setX(me.getX()-=2); 
			If(b.getX()>me.getX())    CoolBot.setX(me.getX()+=2); 
			If(b.getY()>me.getY())    me.setY(me.getY()-=2); 
			If(b.getY()>me.getY())    
			me.setY(me.getY()+=2);
			*/ 
			
			//DODGE BULLETS
			if(liveBots.length>0 ) {
			
			BotInfo closestAlive = helper.findClosest(me, liveBots);
	
			
			//LEFT
			if(closestAlive.getX() > me.getX ()) {
				
				current = left;
				return BattleBotArena.LEFT;
				
			}
			
			//RIGHT
			else if(closestAlive.getX() < me.getX()) {
				
				current = right;
				return BattleBotArena.RIGHT;
					
			}
			
			//UP
			if(closestAlive.getY() > me.getY()) {
				
				current = up;
				return BattleBotArena.UP;
				
			}
			
			//DOWN
			else if(closestAlive.getY() < me.getY()) {
				
				current = down;
				return BattleBotArena.DOWN;
				
			}
			
			}//if deadBots > 0
			
		}//Try
		
		catch(Exception e){
			e.printStackTrace();
		}
		return BattleBotArena.LEFT;
	}

	@Override
	public void draw(Graphics g, int x, int y) {
		// TODO Auto-generated method stub
		g.setColor(Color.green);
		g.drawImage(current, x, y, Bot.RADIUS*2, Bot.RADIUS*2, null);

	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getTeamName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String outgoingMessage() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void incomingMessage(int botNum, String msg) {
		// TODO Auto-generated method stub

	}

	@Override
	public String[] imageNames() {
		// TODO Auto-generated method stub
		String[] images = {"roomba_up.png","roomba_down.png","roomba_left.png","roomba_right.png"};
		//String[] images = {"starfish4.png"};
		return images;
	}
	



	@Override
	public void loadedImages(Image[] images) {
		// TODO Auto-generated method stub
		if (images != null)
		{
			current = up = images[0];
			down = images[1];
			left = images[2];
			right = images[3];
		}
	}

}
